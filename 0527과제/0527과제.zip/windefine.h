﻿#pragma once

#include <windows.h>
#include <windowsx.h>
#include <tchar.h>
#include <stdlib.h> // rand, srand
#include <time.h> // time
#include <sstream> // wostringstream
#define _USE_MATH_DEFINES
#include <math.h>

LRESULT CALLBACK WndProc(HWND,UINT,WPARAM,LPARAM);
